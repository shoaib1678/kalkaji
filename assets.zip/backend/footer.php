<footer>
        <p>© 2024 Kalka ji | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
    </footer>